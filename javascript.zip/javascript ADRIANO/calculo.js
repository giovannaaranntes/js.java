let numero = 10
let numero2 = "10"
console.log(numero === numero2)