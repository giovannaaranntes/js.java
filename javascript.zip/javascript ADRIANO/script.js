//console.log("Adriano")

//var nome = "Adriano" //variavel global não é usada mais
//let nome2 = "Fulano" //variavel de escopo
//const nome3 = "Cicrano"

const preco = 10
let preco2
preco2 = 20

let nomedomeucachorro ="Caramelo"
let nome_do_meu_cachorro2 = "Caramelo" //snakecase
let nomeDoMeuCachorro = "Caramelo" //camelcase

let x = "Caramelo"
let y = "Caramelo"

//concatenação
let nome_do_meu_cachorro = "Caramelo"
let nomeDoMeuGato = "Salem"

let nomes_dos_pets = 
nome_do_meu_cachorro + " " + nomeDoMeuGato

let nome_dos_pais = "João"+" "+"Maria"

//tipos de dados
//string
let nome = "Adriano" 
let letra = "a"
let frase = " Uma pequena frase"
//number
let idade = 25
let peso = 68.5
let altura = 1.70
let preco3 = 200.00
let temperatura = -5
//boolean
let habilitado = true
let maio_de_idade = true
let casado = false
//null
null
undefined

//array
let nomes = ["Adriano", "Maria", "João"]
let numeros = [1,2,3,4,5]
let boolean = [true, false, true]
let objetos = [{nome: "Adriano", idade: 20},
               {nome: "Maria", idade: 22},
               {nome: "João", idade: 21} ]


//object
let pessoa = {nome: "Adriano", idade: 30}
let pessoa2 = {nome: "Maria", idade: 20}

let pessoa3 = {
    nome: "João",
    idade: 22
}

//operadores
//aritemeticos
console.log(2 + 5)// adição
console.log(2 - 5)// subtração
console.log(2 * 5)// multiplição
console.log(2 / 5) // divisão
console.log(5 ** 2) //operador de potencia
console.log(5 % 2)// resto da divisão
//relacionais
console.log(5 > 2)// operador de maior
console.log(5 < 2)// operador de menor
console.log(5 >= 2)// maior ou igual
console.log(5 <= 2)//menor ou igual
console.log(5 == 5)//true ou igual
//logicos
console.log(true && true)//true operador e
console.log(true && false)//false operador e
console.log(true || false)//true operador ou
console.log(false || false)//false operador ou
console.log(!true)//false operador nao
console.log(!false)//true operador nao